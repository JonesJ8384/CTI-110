import turtle

wn = turtle.Screen()
wn.bgcolor("blue")

jj = turtle.Turtle()

jj.shape("turtle")

jj.color("red")

jj.speed(1)

jj.forward(20)

jj.left(180)

jj.forward(10)

jj.left(90)

jj.forward(35)

jj.right(90)

jj.forward(10)

jj.right(90)

jj.forward(10)

jj.penup()

jj.forward(25)

jj.left(90)

jj.forward(40)

jj.pendown()

jj.right(180)

jj.forward(20)

jj.left(180)

jj.forward(10)

jj.left(90)

jj.forward(35)

jj.right(90)

jj.forward(10)

jj.right(90)

jj.forward(10)

jj.penup()

jj.forward(100)

jj.right(90)

jj.pendown()

jj.forward(50)

jj.left(120)

jj.forward(50)

jj.left(120)

jj.forward(50)

jj.left(30)

jj.forward(50)

jj.left(90)

jj.forward(50)

jj.left(90)

jj.forward(50)

wn.mainloop()